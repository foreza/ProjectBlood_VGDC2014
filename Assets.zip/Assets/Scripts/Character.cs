﻿using UnityEngine;
using System.Collections;

public class Character : MonoBehaviour {

	public float health;
	public float speed;
	void Start () 
	{

	}
	
	// Update is called once per frame
	void Update () 
	{
		
	}
}
