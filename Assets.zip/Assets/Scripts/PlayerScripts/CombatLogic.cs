
// ------------------------------------------------------------------------------
using System;
namespace AssemblyCSharp
{
		public class CombatLogic
		{
				public CombatLogic ()
				{
				}
		}
}

