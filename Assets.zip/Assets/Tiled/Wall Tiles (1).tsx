<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Wall Tiles (1)" tilewidth="32" tileheight="32">
 <image source="../../../../../Google Drive/Project BLOOD/Art/Tiles/Wall Tiles (1).png" width="416" height="32"/>
</tileset>
