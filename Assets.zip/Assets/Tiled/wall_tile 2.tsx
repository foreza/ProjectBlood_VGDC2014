<?xml version="1.0" encoding="UTF-8"?>
<tileset name="wall_tile 2" tilewidth="32" tileheight="32">
 <image source="../../../../../Google Drive/Project BLOOD/Art/Tiles/Wall Tiles.png" width="416" height="32"/>
 <tile id="0">
  <objectgroup draworder="index">
   <object x="6.0625" y="0" width="19.6875" height="31.875"/>
  </objectgroup>
 </tile>
 <tile id="1">
  <objectgroup draworder="index">
   <object x="6.0625" y="0" width="19.9375" height="32"/>
  </objectgroup>
 </tile>
 <tile id="2">
  <objectgroup draworder="index">
   <object x="6" y="0" width="19.9375" height="25.9375"/>
   <object x="25.875" y="5.9375" width="6.1875" height="20.0625"/>
  </objectgroup>
 </tile>
 <tile id="3">
  <objectgroup draworder="index">
   <object x="5.9375" y="-0.0625" width="19.9375" height="32"/>
   <object x="26" y="6.1875" width="6" height="19.75"/>
  </objectgroup>
 </tile>
 <tile id="4">
  <objectgroup draworder="index">
   <object x="5.9375" y="-0.0625" width="20.0625" height="31.9375"/>
   <object x="0" y="5.9375" width="32" height="20.1875"/>
  </objectgroup>
 </tile>
 <tile id="5">
  <objectgroup draworder="index">
   <object x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
</tileset>
