
===========
This is PROJECT BLOOD! 

### Current Version of Game : v1.0 (Begin Tracking)

##Changelog

- v1.0
  - Started keeping track of the changes on the READme, for good habit.
  - Cleaned up the repository, moved scripts into appropriate folders.
  - Fixed up Enemy AI - should drop breadcrumbs and AI should follow breadcrumbs as intended when loss of vision.
  - Made more prefabs - should be able to drag + drop and start a new level

Improvements for v1.1:
  * Add some screenshots for the game
  * Implementation of full combat system.
  * Update more builds for the game (shooting for a new build by 1.3)
  * More levels.
  * Better pathfinding algorithm.
  * Better boss sprite
  * Quest objectives

